/*****************************************************************************
** Bubble Sort
** Compile:
**		% gcc -bubblesort.c -o bubblesort.exe 
******************************************************************************/

#include <stdio.h>
#include <stdlib.h>

#define  DATANUM  8

int main(void){
	
	int b_ary[DATANUM] ;
	int cnti ,cntj ,tmp ;
	
	FILE  *fp1, *fp2 ;
	
	if ((fp1 = fopen("indata.txt", "r")) == NULL) {
		fprintf(stderr, "file indata.txt not open \n");
		exit(1);
	}
	
	if ((fp2 = fopen("otdata.txt", "w")) == NULL) {
		fprintf(stderr, "file otdata.txt not open \n");
		exit(1);
	}
	
    for(cnti = 0 ; cnti < DATANUM ; cnti++){
		if (fscanf(fp1, "%d", &b_ary[cnti]) == EOF) exit(0);
	}
	
    for(cnti = 0 ; cnti < DATANUM ; cnti++){
		for(cntj = DATANUM-1 ; cntj > cnti ; cntj--){
			if(b_ary[cntj] < b_ary[cntj-1]){
				tmp           = b_ary[cntj] ;
				b_ary[cntj]   = b_ary[cntj-1] ;
				b_ary[cntj-1] = tmp ;
			}
		}
	}
    
    for(cnti = 0 ;cnti < DATANUM ;cnti++){
		fprintf(fp2, "%d\n", b_ary[cnti]) ;
	}
	fclose(fp1) ;
	fclose(fp2) ;
	return 0 ;
}
