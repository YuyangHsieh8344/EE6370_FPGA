#include <stdio.h>
#include <stdint.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>

#include "hwlib.h"
#include "socal/socal.h"
#include "socal/hps.h"

// ---------------- HPS ↔ FPGA bridge 定義 ----------------
#define HW_REGS_BASE   (ALT_STM_OFST)
#define HW_REGS_SPAN   (0x04000000)
#define HW_REGS_MASK   (HW_REGS_SPAN - 1)

// 在 Qsys 裡，aes128_accel_0 掛在 LW bridge offset = 0x0
#define AES_BASE       0x00000000
#define AES_SPAN       0x00000100

// register index (★「word index」，對應 Verilog 的 address 0..12)
#define AES_REG_KEY0   0
#define AES_REG_KEY1   1
#define AES_REG_KEY2   2
#define AES_REG_KEY3   3
#define AES_REG_PT0    4
#define AES_REG_PT1    5
#define AES_REG_PT2    6
#define AES_REG_PT3    7
#define AES_REG_CT0    8
#define AES_REG_CT1    9
#define AES_REG_CT2   10
#define AES_REG_CT3   11
#define AES_REG_CTRL  12

// control bits
#define AES_CTRL_START 0x1
#define AES_CTRL_DONE  0x2   // 目前 RTL 雖然有 DONE，我們先不 busy-wait

// --------- 工具：4 byte <-> 32-bit (big-endian) ----------
static uint32_t pack_be(const uint8_t *b) {
    return ((uint32_t)b[0] << 24) |
           ((uint32_t)b[1] << 16) |
           ((uint32_t)b[2] <<  8) |
           ((uint32_t)b[3]      );
}

static void unpack_be(uint32_t w, uint8_t *b) {
    b[0] = (uint8_t)((w >> 24) & 0xFF);
    b[1] = (uint8_t)((w >> 16) & 0xFF);
    b[2] = (uint8_t)((w >>  8) & 0xFF);
    b[3] = (uint8_t)( w        & 0xFF);
}

// --------- 軟體 AES 函式宣告（你原本的） ---------
void aes_encrypt_128(const uint8_t in[16],
                     const uint8_t key[16],
                     uint8_t out[16]);

// ========================= main =========================
int main(void) {

    // 固定一組 key / plaintext 來 debug
    static const uint8_t key[16] = {
        0xf6,0x02,0x6b,0x39,0x73,0x87,0x97,0xcf,
        0xca,0xcb,0x67,0x9a,0xf0,0x9a,0x31,0x74
    };

    uint8_t pt[16] = {
        0x31,0x32,0x33,0x34,
        0x35,0x36,0x37,0x38,
        0x39,0x31,0x32,0x33,
        0x34,0x35,0x36,0x37
    };

    uint8_t ct_sw[16];

    // ---------- 1. Software AES ----------
    aes_encrypt_128(pt, key, ct_sw);

    printf("=== Software AES (Golden) ===\n");
    printf("Key       : ");
    for (int i = 0; i < 16; i++) printf("%02x", key[i]);
    printf("\n");

    printf("Plaintext : ");
    for (int i = 0; i < 16; i++) printf("%02x", pt[i]);
    printf("\n");

    printf("SW Cipher : ");
    for (int i = 0; i < 16; i++) printf("%02x", ct_sw[i]);
    printf("\n\n");

    // ---------- 2. /dev/mem + mmap ----------
    int fd;
    void *virtual_base;
    volatile uint32_t *aes_regs;

    fd = open("/dev/mem", O_RDWR | O_SYNC);
    if (fd == -1) {
        perror("ERROR: open /dev/mem failed");
        return 1;
    }

    virtual_base = mmap(
        NULL,
        HW_REGS_SPAN,
        PROT_READ | PROT_WRITE,
        MAP_SHARED,
        fd,
        HW_REGS_BASE
    );
    if (virtual_base == MAP_FAILED) {
        perror("ERROR: mmap() failed");
        close(fd);
        return 1;
    }

    // 指到 LW bridge + AES_BASE
    aes_regs = (volatile uint32_t *)(
        (uint8_t *)virtual_base +
        ((ALT_LWFPGASLVS_OFST + AES_BASE) & HW_REGS_MASK)
    );

    // ---------- 3. write key / plaintext to FPGA ----------
    uint32_t key_words[4];
    uint32_t pt_words[4];

    for (int i = 0; i < 4; i++) {
        key_words[i] = pack_be(&key[4*i]);
        pt_words[i]  = pack_be(&pt[4*i]);

        // ★ 這裡用的是「word index」，對應 Verilog address 0..7
        aes_regs[AES_REG_KEY0 + i] = key_words[i];
        aes_regs[AES_REG_PT0  + i] = pt_words[i];
    }

    printf("Key words written to FPGA:\n  ");
    for (int i = 0; i < 4; i++) printf("%08x ", key_words[i]);
    printf("\n");

    printf("PT words written to FPGA:\n  ");
    for (int i = 0; i < 4; i++) printf("%08x ", pt_words[i]);
    printf("\n");

    // ---------- 3b. 立刻從 FPGA 讀回來 check ----------
    printf("\nKey words read back from FPGA:\n  ");
    for (int i = 0; i < 4; i++) {
        printf("%08x ", aes_regs[AES_REG_KEY0 + i]);
    }
    printf("\n");

    printf("PT words read back from FPGA :\n  ");
    for (int i = 0; i < 4; i++) {
        printf("%08x ", aes_regs[AES_REG_PT0 + i]);
    }
    printf("\n\n");

    // ---------- 4. start hardware AES ----------
    aes_regs[AES_REG_CTRL] = AES_CTRL_START;

#if 0
    // 如果之後想用 DONE，可以把 RTL 的 done_flag 拉低的邏輯補好，再打開這段
    while ((aes_regs[AES_REG_CTRL] & AES_CTRL_DONE) == 0) {
        // busy wait
    }
#endif

    // ---------- 5. read ciphertext from FPGA ----------
    uint32_t ct_words[4];
    uint8_t  ct_hw[16];

    for (int i = 0; i < 4; i++) {
        ct_words[i] = aes_regs[AES_REG_CT0 + i];  // word index 8..11
        unpack_be(ct_words[i], &ct_hw[4*i]);
    }

    printf("CT words read back from FPGA :\n  ");
    for (int i = 0; i < 4; i++) {
        printf("%08x ", aes_regs[AES_REG_CT0 + i]);
    }
    printf("\n");

    printf("\n=== FPGA AES ===\n");
    printf("HW CT words (32-bit):\n  ");
    for (int i = 0; i < 4; i++) printf("%08x ", ct_words[i]);
    printf("\n");

    printf("HW Cipher (bytes): ");
    for (int i = 0; i < 16; i++) printf("%02x", ct_hw[i]);
    printf("\n");

    // ---------- 6. cleanup ----------
    if (munmap(virtual_base, HW_REGS_SPAN) != 0) {
        perror("ERROR: munmap() failed");
    }
    close(fd);

    return 0;
}
