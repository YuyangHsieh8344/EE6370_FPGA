#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>

#include "hwlib.h"
#include "socal/socal.h"
#include "socal/hps.h"

// ---------------- HPS ↔ FPGA bridge 定義 ----------------
#define HW_REGS_BASE   (ALT_STM_OFST)
#define HW_REGS_SPAN   (0x04000000)
#define HW_REGS_MASK   (HW_REGS_SPAN - 1)

// 你在 Qsys 設定 aes128_accel_0 的 base (我之前幫你設在 0x0)
#define AES_BASE       0x00000000
#define AES_SPAN       0x00000100

// register index (word index)
#define AES_REG_KEY0   0
#define AES_REG_KEY1   1
#define AES_REG_KEY2   2
#define AES_REG_KEY3   3
#define AES_REG_PT0    4
#define AES_REG_PT1    5
#define AES_REG_PT2    6
#define AES_REG_PT3    7
#define AES_REG_CT0    8
#define AES_REG_CT1    9
#define AES_REG_CT2   10
#define AES_REG_CT3   11
#define AES_REG_CTRL  12

// control bits
#define AES_CTRL_START 0x1
#define AES_CTRL_DONE  0x2   // 如果你的硬體沒有 DONE，可以暫時沒用到

// --------- helper: 把 4 個 byte 打包成 1 個 32-bit (big-endian) ----------
static uint32_t pack_be(const uint8_t *b) {
    return ((uint32_t)b[0] << 24) |
           ((uint32_t)b[1] << 16) |
           ((uint32_t)b[2] <<  8) |
           ((uint32_t)b[3]      );
}

static void unpack_be(uint32_t w, uint8_t *b) {
    b[0] = (uint8_t)((w >> 24) & 0xFF);
    b[1] = (uint8_t)((w >> 16) & 0xFF);
    b[2] = (uint8_t)((w >>  8) & 0xFF);
    b[3] = (uint8_t)( w        & 0xFF);
}

// --------- 這裡宣告你 AES 軟體函式（用你實際的名字替換） ---------
// 假設你的 aes.c 有這兩個函式：
//   void aes_encrypt_128(const uint8_t in[16],
//                        const uint8_t key[16],
//                        uint8_t out[16]);
//   void aes_decrypt_128(const uint8_t in[16],
//                        const uint8_t key[16],
//                        uint8_t out[16]);
void aes_encrypt_128(const uint8_t in[16],
                     const uint8_t key[16],
                     uint8_t out[16]);

void aes_decrypt_128(const uint8_t in[16],
                     const uint8_t key[16],
                     uint8_t out[16]);

// ========================= main =========================
int main(void) {
    // ---------- 1. 產生亂數 key ----------
    uint8_t key[16];
    srand((unsigned)time(NULL));
    for (int i = 0; i < 16; i++) {
        key[i] = (uint8_t)(rand() & 0xFF);
    }

    // ---------- 2. 讀 plaintext ----------
    char input_buf[64];
    uint8_t pt[16] = {0};

    printf("Enter plaintext (<=16 characters): ");
    fflush(stdout);
    if (fgets(input_buf, sizeof(input_buf), stdin) == NULL) {
        printf("Input error.\n");
        return 1;
    }
    // 去掉換行
    size_t len = strcspn(input_buf, "\r\n");
    input_buf[len] = '\0';
    if (len > 16) len = 16;
    // 複製到 16-byte buffer，剩下的自動維持 0
    memcpy(pt, input_buf, len);

    // ---------- 3. SW AES 加/解密 (golden) ----------
    uint8_t ct_sw[16];
    uint8_t pt_sw_dec[16];

    // TODO: 用你自己的 AES 加解密函式
    aes_encrypt_128(pt, key, ct_sw);      // SW encrypt
    aes_decrypt_128(ct_sw, key, pt_sw_dec); // SW decrypt

    // ---------- 4. 印出 key / plaintext / SW 結果 ----------
    printf("\n=== Software AES (Golden) ===\n");
    printf("Encryption Key (hex): ");
    for (int i = 0; i < 16; i++) {
        printf("%02x", key[i]);
    }
    printf("\n");

    printf("Original plaintext (string): %s\n", input_buf);

    printf("Software Ciphertext (hex): ");
    for (int i = 0; i < 16; i++) {
        printf("%02x", ct_sw[i]);
    }
    printf("\n");

    printf("Software Decrypted plaintext (string): ");
    for (int i = 0; i < 16; i++) {
        putchar(pt_sw_dec[i] ? pt_sw_dec[i] : '.'); // 0 用 '.' 看比較清楚
    }
    printf("\n");

    // ---------- 5. /dev/mem + mmap，取得 aes128_accel pointer ----------
    int fd;
    void *virtual_base;
    volatile uint32_t *aes_regs;

    fd = open("/dev/mem", O_RDWR | O_SYNC);
    if (fd == -1) {
        perror("ERROR: open /dev/mem failed");
        return 1;
    }

    virtual_base = mmap(NULL,
                        HW_REGS_SPAN,
                        PROT_READ | PROT_WRITE,
                        MAP_SHARED,
                        fd,
                        HW_REGS_BASE);
    if (virtual_base == MAP_FAILED) {
        perror("ERROR: mmap() failed");
        close(fd);
        return 1;
    }

    aes_regs = (volatile uint32_t *)(
                   (uint8_t *)virtual_base +
                   ((ALT_LWFPGASLVS_OFST + AES_BASE) & HW_REGS_MASK));

    // ---------- 6. 寫 key / plaintext 到 FPGA ----------
    for (int i = 0; i < 4; i++) {
        aes_regs[AES_REG_KEY0 + i] = pack_be(&key[4*i]);
        aes_regs[AES_REG_PT0  + i] = pack_be(&pt[4*i]);
    }

    // ---------- 7. 啟動硬體 AES ----------
    aes_regs[AES_REG_CTRL] = AES_CTRL_START;

    // 如果 RTL 有實作 DONE bit，就在這裡等待
    //while ((aes_regs[AES_REG_CTRL] & AES_CTRL_DONE) == 0) {
        // busy-wait：等 AES 核完成
    //}

    // ---------- 8. 讀回 ciphertext ----------
    uint32_t ct_words[4];
    uint8_t  ct_hw[16];
    for (int i = 0; i < 4; i++) {
        ct_words[i] = aes_regs[AES_REG_CT0 + i];
        unpack_be(ct_words[i], &ct_hw[4*i]);
    }

    // ---------- 9. 用 SW 解密 FPGA 結果 ----------
    uint8_t pt_hw_dec[16];
    aes_decrypt_128(ct_hw, key, pt_hw_dec);

    // ---------- 10. 印出 HW 結果（符合作業要求格式） ----------
    printf("\n=== HPS–FPGA AES System ===\n");

    printf("Encryption Key (hex): ");
    for (int i = 0; i < 16; i++) {
        printf("%02x", key[i]);
    }
    printf("\n");

    printf("Original plaintext (string): %s\n", input_buf);

    printf("Ciphertext from FPGA (hex): ");
    for (int i = 0; i < 16; i++) {
        printf("%02x", ct_hw[i]);
    }
    printf("\n");

    printf("Plaintext from FPGA (string): ");
    for (int i = 0; i < 16; i++) {
        putchar(pt_hw_dec[i] ? pt_hw_dec[i] : '.');
    }
    printf("\n");

    // ---------- 11. 資源清理 ----------
    if (munmap(virtual_base, HW_REGS_SPAN) != 0) {
        perror("ERROR: munmap() failed");
    }
    close(fd);

    return 0;
}

/*********************************************************
 * 在這行下面，把你原本 aes.c 裡面所有 AES 函式貼過來
 *（包含 S-box、KeySchedule、加解密核心等等）
 * main() 就用上面這個，不要再留舊的 main。
 *********************************************************/

// ---------- AES-128 implementation (FIPS-197 compatible) ----------

#include <stdint.h>

static const uint8_t sbox[256] = {
    0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
    0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
    0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
    0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
    0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
    0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
    0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
    0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
    0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
    0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
    0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
    0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
    0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
    0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
    0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
    0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16
};

static const uint8_t inv_sbox[256] = {
    0x52,0x09,0x6a,0xd5,0x30,0x36,0xa5,0x38,0xbf,0x40,0xa3,0x9e,0x81,0xf3,0xd7,0xfb,
    0x7c,0xe3,0x39,0x82,0x9b,0x2f,0xff,0x87,0x34,0x8e,0x43,0x44,0xc4,0xde,0xe9,0xcb,
    0x54,0x7b,0x94,0x32,0xa6,0xc2,0x23,0x3d,0xee,0x4c,0x95,0x0b,0x42,0xfa,0xc3,0x4e,
    0x08,0x2e,0xa1,0x66,0x28,0xd9,0x24,0xb2,0x76,0x5b,0xa2,0x49,0x6d,0x8b,0xd1,0x25,
    0x72,0xf8,0xf6,0x64,0x86,0x68,0x98,0x16,0xd4,0xa4,0x5c,0xcc,0x5d,0x65,0xb6,0x92,
    0x6c,0x70,0x48,0x50,0xfd,0xed,0xb9,0xda,0x5e,0x15,0x46,0x57,0xa7,0x8d,0x9d,0x84,
    0x90,0xd8,0xab,0x00,0x8c,0xbc,0xd3,0x0a,0xf7,0xe4,0x58,0x05,0xb8,0xb3,0x45,0x06,
    0xd0,0x2c,0x1e,0x8f,0xca,0x3f,0x0f,0x02,0xc1,0xaf,0xbd,0x03,0x01,0x13,0x8a,0x6b,
    0x3a,0x91,0x11,0x41,0x4f,0x67,0xdc,0xea,0x97,0xf2,0xcf,0xce,0xf0,0xb4,0xe6,0x73,
    0x96,0xac,0x74,0x22,0xe7,0xad,0x35,0x85,0xe2,0xf9,0x37,0xe8,0x1c,0x75,0xdf,0x6e,
    0x47,0xf1,0x1a,0x71,0x1d,0x29,0xc5,0x89,0x6f,0xb7,0x62,0x0e,0xaa,0x18,0xbe,0x1b,
    0xfc,0x56,0x3e,0x4b,0xc6,0xd2,0x79,0x20,0x9a,0xdb,0xc0,0xfe,0x78,0xcd,0x5a,0xf4,
    0x1f,0xdd,0xa8,0x33,0x88,0x07,0xc7,0x31,0xb1,0x12,0x10,0x59,0x27,0x80,0xec,0x5f,
    0x60,0x51,0x7f,0xa9,0x19,0xb5,0x4a,0x0d,0x2d,0xe5,0x7a,0x9f,0x93,0xc9,0x9c,0xef,
    0xa0,0xe0,0x3b,0x4d,0xae,0x2a,0xf5,0xb0,0xc8,0xeb,0xbb,0x3c,0x83,0x53,0x99,0x61,
    0x17,0x2b,0x04,0x7e,0xba,0x77,0xd6,0x26,0xe1,0x69,0x14,0x63,0x55,0x21,0x0c,0x7d
};

static const uint8_t Rcon[11] = {
    0x00, /* unused */
    0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1B,0x36
};

static uint8_t xtime(uint8_t x) {
    return (uint8_t)((x << 1) ^ ((x & 0x80) ? 0x1b : 0x00));
}

static uint8_t gf_mul(uint8_t a, uint8_t b) {
    uint8_t res = 0;
    while (b) {
        if (b & 1) res ^= a;
        a = xtime(a);
        b >>= 1;
    }
    return res;
}

static void AddRoundKey(uint8_t *state, const uint8_t *roundKey) {
    for (int i = 0; i < 16; i++) {
        state[i] ^= roundKey[i];
    }
}

static void SubBytes(uint8_t *state) {
    for (int i = 0; i < 16; i++) {
        state[i] = sbox[state[i]];
    }
}

static void InvSubBytes(uint8_t *state) {
    for (int i = 0; i < 16; i++) {
        state[i] = inv_sbox[state[i]];
    }
}

static void ShiftRows(uint8_t *s) {
    uint8_t tmp;

    // row 1 (index 1,5,9,13) left shift by 1
    tmp   = s[1];
    s[1]  = s[5];
    s[5]  = s[9];
    s[9]  = s[13];
    s[13] = tmp;

    // row 2 (index 2,6,10,14) left shift by 2
    tmp   = s[2];  s[2]  = s[10]; s[10] = tmp;
    tmp   = s[6];  s[6]  = s[14]; s[14] = tmp;

    // row 3 (index 3,7,11,15) left shift by 3
    tmp   = s[3];
    s[3]  = s[15];
    s[15] = s[11];
    s[11] = s[7];
    s[7]  = tmp;
}

static void InvShiftRows(uint8_t *s) {
    uint8_t tmp;

    // row 1 right shift by 1
    tmp   = s[13];
    s[13] = s[9];
    s[9]  = s[5];
    s[5]  = s[1];
    s[1]  = tmp;

    // row 2 right shift by 2
    tmp   = s[2];  s[2]  = s[10]; s[10] = tmp;
    tmp   = s[6];  s[6]  = s[14]; s[14] = tmp;

    // row 3 right shift by 3
    tmp   = s[3];
    s[3]  = s[7];
    s[7]  = s[11];
    s[11] = s[15];
    s[15] = tmp;
}

static void MixColumns(uint8_t *s) {
    for (int c = 0; c < 4; c++) {
        int i = 4 * c;
        uint8_t a0 = s[i + 0];
        uint8_t a1 = s[i + 1];
        uint8_t a2 = s[i + 2];
        uint8_t a3 = s[i + 3];

        s[i + 0] = (uint8_t)(gf_mul(a0, 2) ^ gf_mul(a1, 3) ^ a2 ^ a3);
        s[i + 1] = (uint8_t)(a0 ^ gf_mul(a1, 2) ^ gf_mul(a2, 3) ^ a3);
        s[i + 2] = (uint8_t)(a0 ^ a1 ^ gf_mul(a2, 2) ^ gf_mul(a3, 3));
        s[i + 3] = (uint8_t)(gf_mul(a0, 3) ^ a1 ^ a2 ^ gf_mul(a3, 2));
    }
}

static void InvMixColumns(uint8_t *s) {
    for (int c = 0; c < 4; c++) {
        int i = 4 * c;
        uint8_t a0 = s[i + 0];
        uint8_t a1 = s[i + 1];
        uint8_t a2 = s[i + 2];
        uint8_t a3 = s[i + 3];

        s[i + 0] = (uint8_t)(gf_mul(a0, 0x0e) ^ gf_mul(a1, 0x0b) ^
                             gf_mul(a2, 0x0d) ^ gf_mul(a3, 0x09));
        s[i + 1] = (uint8_t)(gf_mul(a0, 0x09) ^ gf_mul(a1, 0x0e) ^
                             gf_mul(a2, 0x0b) ^ gf_mul(a3, 0x0d));
        s[i + 2] = (uint8_t)(gf_mul(a0, 0x0d) ^ gf_mul(a1, 0x09) ^
                             gf_mul(a2, 0x0e) ^ gf_mul(a3, 0x0b));
        s[i + 3] = (uint8_t)(gf_mul(a0, 0x0b) ^ gf_mul(a1, 0x0d) ^
                             gf_mul(a2, 0x09) ^ gf_mul(a3, 0x0e));
    }
}

// KeyExpansion: 16-byte key -> 176-byte roundKey (11 * 16)
static void KeyExpansion(const uint8_t key[16], uint8_t roundKey[176]) {
    // copy original key
    for (int i = 0; i < 16; i++) {
        roundKey[i] = key[i];
    }

    uint8_t temp[4];
    int bytesGenerated = 16;
    int rconIter = 1;

    while (bytesGenerated < 176) {
        // 上一個 word (4 bytes)
        for (int i = 0; i < 4; i++) {
            temp[i] = roundKey[bytesGenerated - 4 + i];
        }

        if (bytesGenerated % 16 == 0) {
            // 左循環 1 byte
            uint8_t t = temp[0];
            temp[0] = temp[1];
            temp[1] = temp[2];
            temp[2] = temp[3];
            temp[3] = t;

            // S-box
            for (int i = 0; i < 4; i++) {
                temp[i] = sbox[temp[i]];
            }

            // XOR Rcon
            temp[0] ^= Rcon[rconIter++];
        }

        // 新的 4 bytes = 前 16 bytes 之前的 4 bytes XOR temp
        for (int i = 0; i < 4; i++) {
            roundKey[bytesGenerated] =
                (uint8_t)(roundKey[bytesGenerated - 16] ^ temp[i]);
            bytesGenerated++;
        }
    }
}

// 公開的 API：單一 128-bit block 加密
void aes_encrypt_128(const uint8_t in[16],
                     const uint8_t key[16],
                     uint8_t out[16]) {

    uint8_t state[16];
    uint8_t roundKey[176];  // 11 個 round keys

    // copy input
    for (int i = 0; i < 16; i++) {
        state[i] = in[i];
    }

    KeyExpansion(key, roundKey);

    // round 0
    AddRoundKey(state, roundKey);

    // round 1~9
    for (int round = 1; round <= 9; round++) {
        SubBytes(state);
        ShiftRows(state);
        MixColumns(state);
        AddRoundKey(state, roundKey + 16 * round);
    }

    // final round
    SubBytes(state);
    ShiftRows(state);
    AddRoundKey(state, roundKey + 160); // 10 * 16

    for (int i = 0; i < 16; i++) {
        out[i] = state[i];
    }
}

// 公開的 API：單一 128-bit block 解密
void aes_decrypt_128(const uint8_t in[16],
                     const uint8_t key[16],
                     uint8_t out[16]) {

    uint8_t state[16];
    uint8_t roundKey[176];

    for (int i = 0; i < 16; i++) {
        state[i] = in[i];
    }

    KeyExpansion(key, roundKey);

    // 初始 AddRoundKey 用最後一組 round key
    AddRoundKey(state, roundKey + 160); // round 10

    // round 9~1
    for (int round = 9; round >= 1; round--) {
        InvShiftRows(state);
        InvSubBytes(state);
        AddRoundKey(state, roundKey + 16 * round);
        InvMixColumns(state);
    }

    // final round
    InvShiftRows(state);
    InvSubBytes(state);
    AddRoundKey(state, roundKey); // round 0

    for (int i = 0; i < 16; i++) {
        out[i] = state[i];
    }
}
